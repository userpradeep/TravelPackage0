package main.java;

import java.util.List;
import java.util.ArrayList;

class TravelPackage {
	private String name;
	private int capacity;
	private List<Destination> itinerary;
	private List<Passenger> passengers;

	public TravelPackage(String name, int capacity) {
		this.name = name;
		this.capacity = capacity;
		this.itinerary = new ArrayList<>();
		this.passengers = new ArrayList<>();

	}

	public void addPassenger(Passenger passenger) {
		if (passengers.size() < capacity) {
			passengers.add(passenger);
		} else {
			System.out.println("Sorry! Can't add more passangers");
		}
	}

	public void addDestination(Destination destination) {
		itinerary.add(destination);
	}

	public void printItinary() {
		System.out.println("*******Itinerary********");
		System.out.println();
		System.out.println("Travel Package" + name);
		System.out.println("Some of the destinations we have");
		for (Destination destination : itinerary) {
			destination.printDetails();
		}
		System.out.println();
		System.out.println("***********");
		System.out.println();
	}

	public void printPassengerList() {
		System.out.println();
		System.out.println("******Passengers List*****");
		System.out.println();
		System.out.println("Passanger List for Travel Package" + name);
		System.out.println("Passangers Capacity" + capacity);
		System.out.println(" " + passengers.size() + "Passangers Currently Enrolled");
		for (Passenger passenger : passengers) {
			System.out.println("Name = " + name + " , " + "Number = " + passenger.getPassengerNumber());
		}
		System.out.println();
		System.out.println("***********");
		System.out.println();
	}

	public void printPassangerDetails(Passenger passanger) {

		System.out.println("*******Detail******");
		System.out.println();
		passanger.printDetails();
		System.out.println();
		System.out.println("************");
		System.out.println();
	}

	public void printAvailableActivities() {
		System.out.println("********AvailableActivity******");
		System.out.println();
		System.out.println("Available Activities:");
		for (Destination destination : itinerary) {
			for (Activity activity : destination.getActivities()) {
				System.out.println("Activity: " + activity.getName() + ", Destination: " + destination.getName()
						+ ", Cost: " + activity.getCost() + ", Capacity: " + activity.getCapacity());

			}
		}
		System.out.println();
		System.out.println("***********");
		System.out.println();
	}

}