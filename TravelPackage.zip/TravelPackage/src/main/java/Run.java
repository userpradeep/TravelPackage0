package main.java;

public class Run {
	public static void main(String args[]) {
		TravelPackage tp = new TravelPackage("India", 50);
		Destination d = new Destination("Laksdweep");
		Activity a = new Activity("Agatti Island", "Snorkelling At Agatti Island ", 0.0, 60);
		d.addActivity(a);
		Destination d1 = new Destination("Kerala");
		Activity a1 = new Activity("Kerala",
				"Brew the smell of spices, unleash the serenity of Western Ghats, get drenched in rain, enjoy Kerala backwaters, give your spirituality a twist, visit bird sanctuaries, indulge yourself in adventurous activities, and enjoy other natural marvels of Kerala.",
				2.0, 80);
		d1.addActivity(a1);
		tp.addDestination(d);
		tp.addDestination(d1);
		tp.printItinary();

		Passenger p = new Passenger("Pradeep", 1, PassengerType.STANDARD);
		p.signUpForActivity(a);
		p.printDetails();

		Passenger p1 = new Passenger("Priya", 2, PassengerType.PREMIUM);
		p1.signUpForActivity(a1);
		p1.printDetails();

		tp.addPassenger(p);
		tp.addPassenger(p1);
		tp.printPassengerList();

		tp.printAvailableActivities();

	}

}
