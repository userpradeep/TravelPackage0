package main.java;

import java.util.List;
import java.util.ArrayList;

class Destination {
	private String name;
	private List<Activity> activities;

	public Destination(String name) {
		this.name = name;
		this.activities = new ArrayList<>();
	}

	public void addActivity(Activity activity) {
		activities.add(activity);
	}

	public void printDetails() {
		System.out.println("Destination: " + name);
		for (Activity activity : activities) {
			System.out.println("Activity: " + activity.getName() + ", Cost: " + activity.getCost() + ", Capacity: "
					+ activity.getCapacity() + ", Description: " + activity.getDescription());
		}
	}

	public List<Activity> getActivities() {
		return activities;
	}

	public String getName() {
		return name;
	}
}