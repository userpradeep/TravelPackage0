package main.java;

import java.util.List;
import java.util.ArrayList;

enum PassengerType {
	STANDARD, GOLD, PREMIUM;
}

class Passenger {
	private String name;
	private int passengerNumber;
	private double balance;
	private List<Activity> activities;
	private PassengerType type;

	public Passenger(String name, int passengerNumber, PassengerType type) {
		this.name = name;
		this.passengerNumber = passengerNumber;
		this.type = type;
		this.activities = new ArrayList<>();
	}

	public void signUpForActivity(Activity activity) {
		if (!activity.isFull()) {
			if (type == PassengerType.STANDARD) {
				if (balance >= activity.getCost()) {
					balance -= activity.getCost();
					activities.add(activity);
					activity.signedUpPassengers.add(this);
				} else {
					System.out.println("Insufficient balance for standard passenger.");
				}
			} else if (type == PassengerType.GOLD) {
				double discountedCost = activity.getCost() * 0.9;
				if (balance >= discountedCost) {
					balance -= discountedCost;
					activities.add(activity);
					activity.signedUpPassengers.add(this);
				} else {
					System.out.println("Insufficient balance for gold passenger.");
				}
			} else if (type == PassengerType.PREMIUM) {
				activities.add(activity);
				activity.signedUpPassengers.add(this);
			}
		} else {
			System.out.println("Activity is full.");
		}
	}

	public void printDetails() {
		System.out.println("*******Detail******");
		System.out.println("Passenger Details:");
		System.out.println("Name: " + name);
		System.out.println("Passenger Number: " + passengerNumber);
		if (type == PassengerType.STANDARD || type == PassengerType.GOLD) {
			System.out.println("Balance: " + balance);
		}
		System.out.println("Activities:");
		for (Activity activity : activities) {
			System.out.println("Activity: " + activity.getName() + ", Price Paid: " + getActivityPrice(activity));
		}
		
	}

	private double getActivityPrice(Activity activity) {
		if (type == PassengerType.STANDARD) {
			return activity.getCost();
		} else if (type == PassengerType.GOLD) {
			return activity.getCost() * 0.9;
		} else {
			return 0.0; // Premium passengers do not pay
		}
	}

	public String getName() {
		return name;
	}

	public int getPassengerNumber() {
		return passengerNumber;
	}
}
